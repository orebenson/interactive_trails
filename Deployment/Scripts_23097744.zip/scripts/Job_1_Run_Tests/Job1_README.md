### Scripts for Jenkins Job 1 - "Smart Towns - Run JUnit + WebDriver + Checkstyle + Selenium Tests"

- Build triggered by git push/merge
- Junit, Webdriver, Checkstyle tests run
- Selenium tests run with the script provided, using the .side file provided
- All test reports are generated and published to Jenkins