# script for build job 1
#!/usr/bin/bash
echo "############ RUNNING BUILD ############"
pwd

# run test reports and build project
mysql -u root -pcomsc < src/main/resources/schema.sql
mysql -u root -pcomsc < src/main/resources/data.sql
/opt/gradle/gradle-8.0.2/bin/gradle clean
/opt/gradle/gradle-8.0.2/bin/gradle build
/opt/gradle/gradle-8.0.2/bin/gradle jacocoTestReport
/opt/gradle/gradle-8.0.2/bin/gradle bootjar

# generate selenium report using script
bash ./Deployment/Selenium/generate_selenium_report.sh
# report at /var/lib/jenkins/workspace/"Smart Towns - Run JUnit + WebDriver + Checkstyle + Selenium Tests"/Deployment/Selenium/selenium_results/selenium_report.html