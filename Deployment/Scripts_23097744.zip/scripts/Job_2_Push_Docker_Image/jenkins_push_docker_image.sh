# script for build job 2
#!/usr/bin/bash
echo "############ RUNNING BUILD ############"
pwd

# get jenkins build number
BUILD_NUMBER=${BUILD_NUMBER}

# get latest commit hash
GIT_COMMIT=$(git --git-dir=/var/lib/jenkins/workspace/"Smart Towns - Run JUnit + WebDriver + Checkstyle + Selenium Tests"/.git rev-parse --short HEAD)

# combine jenkins build number and git commit to make build (need build number in order to sort by latest image later)
VERSION="${BUILD_NUMBER}_${GIT_COMMIT}"
echo "BUILDING IMAGE VERSION $VERSION with format: [jenkins build no.]_[git commit hash]"

# copy all the files except the .git repo
rsync -av --exclude='.git' "/var/lib/jenkins/workspace/Smart Towns - Run JUnit + WebDriver + Checkstyle + Selenium Tests/." ./
#cp -r "/var/lib/jenkins/workspace/Smart Towns - Run JUnit + WebDriver + Checkstyle + Selenium Tests/." ./

/opt/gradle/gradle-8.0.2/bin/gradle clean bootjar

# Run the docker file and create the image
docker build -t smart-towns:$VERSION .

# Push the image to docker hub
docker login -u orebenson -p $docker_pass
docker tag smart-towns:$VERSION orebenson/smart-towns:$VERSION
docker push orebenson/smart-towns:$VERSION