### Scripts for Jenkins Job 2 - "Smart Towns - Create and push Docker image"

- Build triggered by completion of job 2
- Dockerfile is run, building Docker image, and versioning it
- Docker image is then pushed to DockerHub, using Jenkins password storage for credentials