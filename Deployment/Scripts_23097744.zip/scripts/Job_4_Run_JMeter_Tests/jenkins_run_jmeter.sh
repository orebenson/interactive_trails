# script for job 4
#!/usr/bin/bash
echo "############ RUNNING BUILD ############"
pwd

if [ -d JMeter ]; then
    cd JMeter
    rm *.*
    cd ../
fi

cp -r "/var/lib/jenkins/workspace/Smart Towns - Run JUnit + WebDriver + Checkstyle + Selenium Tests/Deployment/JMeter" ./

# get the ip from the terraform deployment
SERVER_IP=$(cat "/var/lib/jenkins/workspace/Smart Towns - Terraform pull and run Docker image/Terraform_Docker/floating_ip.txt")

echo "Waiting for web server startup..."
sleep 300 #Takes about 5 minutes for the server to be up and running
LIVE_SITE=$(curl -s $SERVER_IP:8080)
if [[ $LIVE_SITE == *"VZTA"* ]]; then
    echo "Main site running"
else
    echo "Main site site not running"
    echo "."
    echo "."
    exit 1
fi

OUTPUT_FILES=results/server_jmeter_results
cd JMeter
mkdir results
/opt/jmeter/apache-jmeter-5.5/bin/jmeter -Jserver_ip=$SERVER_IP -Joutput_file=$OUTPUT_FILES -n -t Server_Test_Plan.jmx -l results/tmp.log