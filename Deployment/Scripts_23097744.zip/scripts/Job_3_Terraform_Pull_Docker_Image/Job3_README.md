### Scripts for Jenkins Job 3 - "Smart Towns - Terraform pull and run Docker image"

- Build triggered by completion of job 2
- Spin up new instance with terraform
- Write ip of new instance to txt file for testing
- On new instance, run 4 Docker containers (1 for mariadb, 3 for server)
- Configure nginx to load balance between the 3 server containers