# script for job 3
#!/usr/bin/bash
echo "############ RUNNING BUILD ############"
pwd

export OS_AUTH_URL=https://cscloud.cf.ac.uk:5000
export OS_PROJECT_ID=bfa4a12c0f5e48b0911fbb60f85d542f
export OS_PROJECT_NAME="c23097744"
export OS_USER_DOMAIN_NAME="cardiff.ac.uk"
if [ -z "$OS_USER_DOMAIN_NAME" ]; then unset OS_USER_DOMAIN_NAME; fi
export OS_PROJECT_DOMAIN_ID="3693afdd0603423a9e8984fd32df7a0c"
if [ -z "$OS_PROJECT_DOMAIN_ID" ]; then unset OS_PROJECT_DOMAIN_ID; fi
unset OS_TENANT_ID
unset OS_TENANT_NAME
export OS_USERNAME="c23097744"
export OS_PASSWORD=$c23097744_pass
export OS_REGION_NAME="RegionOne"
if [ -z "$OS_REGION_NAME" ]; then unset OS_REGION_NAME; fi
export OS_INTERFACE=public
export OS_IDENTITY_API_VERSION=3

if [ -d Terraform_Docker ]; then
    cd Terraform_Docker
    /usr/local/bin/terraform destroy -auto-approve
    rm *.*
    cd ../
fi

cp -r "/var/lib/jenkins/workspace/Smart Towns - Run JUnit + WebDriver + Checkstyle + Selenium Tests/Deployment/Terraform_Docker" ./
cd Terraform_Docker
/usr/local/bin/terraform init
/usr/local/bin/terraform plan
/usr/local/bin/terraform apply -auto-approve